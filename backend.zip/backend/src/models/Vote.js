import { DataTypes } from "sequelize";
import sequelize from "../config/db.js";

const Vote = sequelize.define(
  "Vote",
  {
    voteId: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    voterId: {
      type: DataTypes.STRING(50),
      allowNull: false,
    },
    candidateId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    electionId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    voteTime: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    status: {
      type: DataTypes.ENUM("valid", "invalid"),
      defaultValue: "valid",
    },
  },
  {
    tableName: "votes",
    timestamps: false,
  }
);

export default Vote;
