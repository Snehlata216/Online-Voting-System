import Poll from "../models/Poll.js";

/**
 * ✅ Create a new poll
 */
export const createPoll = async (req, res) => {
  try {
    const { question, options, expiresAt } = req.body;

    if (!question || !options || !Array.isArray(options) || options.length < 2) {
      return res.status(400).json({ message: "Question and at least 2 options are required." });
    }

    const formattedOptions = options.map(opt => ({
      text: opt.text,
      votes: opt.votes || 0
    }));

    const poll = await Poll.create({
      question,
      options: formattedOptions,
      totalVotes: 0,
      isActive: true,
      expiresAt: expiresAt || null
    });

    res.status(201).json({ message: "Poll created successfully", poll });
  } catch (error) {
    console.error("Error creating poll:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/**
 * 🗳️ Vote in a poll
 */
export const voteInPoll = async (req, res) => {
  try {
    const { pollId } = req.params;
    const { optionIndex } = req.body;

    const poll = await Poll.findByPk(pollId);
    if (!poll) return res.status(404).json({ message: "Poll not found" });

    // Auto-close expired polls
    if (poll.expiresAt && new Date() > poll.expiresAt) {
      poll.isActive = false;
      await poll.save();
    }

    if (!poll.isActive) {
      return res.status(403).json({ message: "This poll is closed. Voting is not allowed." });
    }

    const options = poll.options;
    if (!Array.isArray(options) || optionIndex < 0 || optionIndex >= options.length) {
      return res.status(400).json({ message: "Invalid option index" });
    }

    // Increment vote
    options[optionIndex].votes += 1;
    poll.totalVotes += 1;

    await poll.update({ options, totalVotes: poll.totalVotes });

    res.json({ message: "Vote recorded successfully", poll });
  } catch (error) {
    console.error("Error voting in poll:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/**
 * 📊 Get poll results with percentages
 */
export const getPollResults = async (req, res) => {
  try {
    const { pollId } = req.params;
    const poll = await Poll.findByPk(pollId);
    if (!poll) return res.status(404).json({ message: "Poll not found" });

    const totalVotes = poll.totalVotes || 0;
    const options = poll.options.map(opt => ({
      text: opt.text,
      votes: opt.votes,
      percentage: totalVotes > 0 ? ((opt.votes / totalVotes) * 100).toFixed(2) : "0.00"
    }));

    res.json({
      pollId: poll.pollId,
      question: poll.question,
      totalVotes,
      isActive: poll.isActive,
      options,
      expiresAt: poll.expiresAt
    });
  } catch (error) {
    console.error("Error fetching poll results:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/**
 * 🧾 Get all polls
 */
export const getAllPolls = async (req, res) => {
  try {
    const polls = await Poll.findAll();
    res.json(polls);
  } catch (error) {
    console.error("Error fetching polls:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/**
 * 🔒 Close poll (Admin only)
 */
export const closePoll = async (req, res) => {
  try {
    const { pollId } = req.params;

    const poll = await Poll.findByPk(pollId);
    if (!poll) return res.status(404).json({ message: "Poll not found" });

    if (!poll.isActive) {
      return res.status(400).json({ message: "Poll is already closed." });
    }

    poll.isActive = false;
    await poll.save();

    res.json({ message: "Poll closed successfully", poll });
  } catch (error) {
    console.error("Error closing poll:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

/**
 * 🔓 Reopen poll (Admin)
 */
export const reopenPoll = async (req, res) => {
  try {
    const { pollId } = req.params;
    const poll = await Poll.findByPk(pollId);
    if (!poll) return res.status(404).json({ message: "Poll not found" });

    poll.isActive = true;
    await poll.save();

    res.json({ message: "Poll reopened successfully", poll });
  } catch (error) {
    console.error("Error reopening poll:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};
