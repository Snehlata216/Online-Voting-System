import Result from "../models/Result.js";
import Election from "../models/Election.js";
import Candidate from "../models/Candidate.js";
import Vote from "../models/Vote.js";

/**
 * 🟢 Create or Update Result
 */
export const createOrUpdateResult = async (req, res) => {
  try {
    const { electionId, winner, totalVotes } = req.body;

    if (!electionId || !winner || !totalVotes) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const election = await Election.findByPk(electionId);
    if (!election) {
      return res.status(404).json({ message: "Election not found" });
    }

    // Check if result already exists
    let existing = await Result.findOne({ where: { electionId } });

    if (existing) {
      await existing.update({ winner, totalVotes, generatedTimestamp: new Date() });
      return res.status(200).json({ message: "Result updated successfully", result: existing });
    }

    // Create new result
    const result = await Result.create({
      electionId,
      winner,
      totalVotes,
    });

    res.status(201).json({ message: "Result created successfully", result });
  } catch (error) {
    console.error("❌ Error saving result:", error);
    res.status(500).json({ message: "Internal server error", error: error.message });
  }
};

/**
 * 🟣 Get all Results
 */
export const getAllResults = async (req, res) => {
  try {
    const results = await Result.findAll({
      include: [{ model: Election, as: "election", attributes: ["title", "status", "startDate", "endDate"] }],
    });
    res.status(200).json(results);
  } catch (error) {
    console.error("❌ Error fetching results:", error);
    res.status(500).json({ message: "Internal server error", error: error.message });
  }
};

/**
 * 🟡 Get result by electionId
 */
export const getResultByElection = async (req, res) => {
  try {
    const { electionId } = req.params;
    const result = await Result.findOne({
      where: { electionId },
      include: [{ model: Election, as: "election", attributes: ["title", "status"] }],
    });

    if (!result) {
      return res.status(404).json({ message: "Result not found for this election" });
    }

    res.status(200).json(result);
  } catch (error) {
    console.error("❌ Error fetching result:", error);
    res.status(500).json({ message: "Internal server error", error: error.message });
  }
};
