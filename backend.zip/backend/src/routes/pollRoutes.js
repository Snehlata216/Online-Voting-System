import express from "express";
import {
  createPoll,
  voteInPoll,
  getPollResults,
  getAllPolls,
  closePoll
} from "../controllers/pollController.js";

const router = express.Router();

// Create poll
router.post("/", createPoll);

// Vote
router.post("/:pollId/vote", voteInPoll);

// All polls
router.get("/", getAllPolls);

// Poll results
router.get("/:pollId/results", getPollResults);

// Close poll
router.put("/:pollId/close", closePoll);

export default router;
