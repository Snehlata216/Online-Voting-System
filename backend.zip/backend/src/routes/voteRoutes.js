import express from "express";
import {
  castVote,
  getAllVotes,
  getVotesByElection,
  getElectionResults,
  invalidateVote
} from "../controllers/voteController.js";

const router = express.Router();

// 🗳️ Voting APIs
router.post("/", castVote);                        // Cast a vote
router.get("/", getAllVotes);                      // Get all votes
router.get("/election/:electionId", getVotesByElection);  // Get votes for an election
router.get("/results/:electionId", getElectionResults);   // Get election results
router.put("/invalidate/:voteId", invalidateVote);        // Invalidate a vote (admin)

export default router;
