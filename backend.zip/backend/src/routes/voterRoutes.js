import express from "express";
import {
  registerVoter,
  loginVoter,
  getAllVoters,
  getVoterById,
  updateVoter,
  deleteVoter,
} from "../controllers/voterController.js";

const router = express.Router();

/**
 * 🗳️ Voter Routes (Base URL: /api/voters)
 */

// 🟢 Register a new voter
router.post("/register", registerVoter);

// 🟣 Login voter
router.post("/login", loginVoter);

// 🟢 Get all voters (public)
router.get("/", getAllVoters);

// 🟢 Get a single voter by ID (public)
router.get("/:id", getVoterById);

// 🟡 Update voter details (public for now)
router.put("/:id", updateVoter);

// 🔴 Delete voter (public for now)
router.delete("/:id", deleteVoter);

export default router;
