import express from "express";
import {
  createOrUpdateResult,
  getAllResults,
  getResultByElection,
} from "../controllers/resultController.js";

const router = express.Router();

// Routes
router.post("/", createOrUpdateResult);       // Add or update result
router.get("/", getAllResults);               // Fetch all results
router.get("/:electionId", getResultByElection); // Fetch result by election

export default router;
